/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pizzeria;

/**
 *
 * @author Calfún
 */
public class Pizza {
    
    private String nombre;
    private String tamaño;
    private String masa;
    
    //Método constructor con parametros
    public Pizza(String nombre, String tamaño, String masa) {
        this.nombre = nombre;
        this.tamaño = tamaño;
        this.masa = masa;
    }
    
    //Método constructor sin parametros
    public Pizza() {
    }
    
    //Métodos mutadores (SET)
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setTamaño(String tamaño) {
        this.tamaño = tamaño;
    }

    public void setMasa(String masa) {
        this.masa = masa;
    }
    
    //Métodos accesadores (GET)
    public String getNombre() {
        return nombre;
    }

    public String getTamaño() {
        return tamaño;
    }

    public String getMasa() {
        return masa;
    }
    
    //Métodos customer (los que me pide el cliente)
    public void preparar(){
        System.out.println("La Pizza "+this.nombre+" se está preparando...");
    }
    public void calentar(){
        System.out.println("La Pizza "+this.nombre+" se está caentando...");
    }
}

