/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pizzeria;

/**
 *
 * @author Calfún
 */
public class Pizzeria {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        Pizza pizza1=new Pizza("Italiana","Mediana","Delgada");
        Pizza pizza2=new Pizza("Bacon","Familiar","Gruesa");
        Pizza pizza3=new Pizza();
        
        
        pizza1.preparar();
        pizza2.calentar();
        
        pizza3.setNombre("Española");
        pizza3.preparar();
        
        pizza2.setNombre("Vegetariana");
        System.out.println("El nombre de la pizza es: "+pizza2.getNombre());
        System.out.println("El tamaño de la pizza es: "+pizza2.getTamaño());
        System.out.println("La masa de la pizza es: "+pizza2.getMasa());
        
        
    }
    
    
}
