/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package colegio;

/**
 *
 * @author W608-PCXX
 */
public class Curso {
    
    private int nroCurso;
    private String profeJefe;
    private int cantAlumnos;

    public Curso(int nroCurso, String profeJefe, int cantAlumnos) {
        this.nroCurso = nroCurso;
        this.profeJefe = profeJefe;
        this.cantAlumnos = cantAlumnos;
    }

    public Curso() {
    }

    public int getNroCurso() {
        return nroCurso;
    }

    public void setNroCurso(int nroCurso) {
        this.nroCurso = nroCurso;
    }

    public String getProfeJefe() {
        return profeJefe;
    }

    public void setProfeJefe(String profeJefe) {
        this.profeJefe = profeJefe;
    }

    public int getCantAlumnos() {
        return cantAlumnos;
    }

    public void setCantAlumnos(int cantAlumnos) {
        this.cantAlumnos = cantAlumnos;
    }

    //Método que muestra los datos del curso
    public void mostrarDatos(){
        
    }
    //Método que muestra el nombre del curso
    public void mostrarNombreCurso(){
        
    }
    
    @Override
    public String toString() {
        return "Curso{" + "nroCurso=" + nroCurso + ", profeJefe=" + profeJefe + ", cantAlumnos=" + cantAlumnos + '}';
    }
    
    
    
}
