package colegio;

import java.util.Scanner;

public class Colegio {

    public static void main(String[] args) {

        //Crear un objeto de tipo Scanner
        Scanner teclado = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("**** Menu de opciones****");
            System.out.println("1.- Opcion 1.");
            System.out.println("2.- Opcion 2.");
            System.out.println("3.- Salir.");
            System.out.print("**Ingrese una opcion** ");
            opcion = teclado.nextInt();
            
            switch(opcion){
                case 1:
                    System.out.println("Ingresaste a la opcion 1.");
                    break;
                case 2:
                    System.out.println("Ingresaste a la opcion 2.");
                    break;
                case 3:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Ingresa un valor valido. Intentalo otra vez.");
                    break;
            }
        } while (opcion != 3);

        //Sentencia While
        /*int contador=1;
        while(contador<6){
            System.out.print(contador+".- ");
            System.out.println("Hola Mundo");
            contador++;//contador=contador+1;
        }
        System.out.println("Se acabo el While...");
         */
        //Sentencia Do-While
        /*int contador=1;
        do{
            System.out.print(contador+".-");
            System.out.println("Hola Mundo");
            contador++;
        }while(contador<6);
        
        System.out.println("Ya termino el Do-While...");*/
        //Ingreso de Datos
    }

}
